import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class CategoryP with ChangeNotifier {

  final String id;
  final String name;
  final String image;
  bool isActive ;
  String selected;

  CategoryP({
    @required this.id,
    @required this.name,
    @required this.image,
    this.isActive=false

  });
  void setValue(String newItem) {
    selected = newItem;

    notifyListeners();
  }
}

class Categories with ChangeNotifier {
  String selected= 'beef';
  void setValue(String newitem) {
    selected = newitem;

    notifyListeners();
  }

  List<CategoryP> _cat = [];

  List<CategoryP> get cat {
    // if (_showFavoritesOnly) {
    //   return _items.where((prodItem) => prodItem.isFavorite).toList();
    // }
    return [..._cat];
  }


  Future<void> fetchAndSetProducts([bool filterByUser = false]) async {

    var url =
        'https://test-8de9e.firebaseio.com/categories.json';
    //  '?auth=$authToken&$filterString;
    try {
      final response = await http.get(url);
      print(json.decode(response.body));
      final extractedData = json.decode(response.body) as Map<String, dynamic>;
      print(json.decode(response.body));
      if (extractedData == null) {
        return;
      }
      //  url =
      //   'https://flutter-update.firebaseio.com/userFavorites/$userId.json?auth=$authToken';
      //final favoriteResponse = await http.get(url);
      //  final favoriteData = json.decode(favoriteResponse.body);
      final List<CategoryP> loadedcat = [];
      extractedData.forEach((prodId, prodData) {
        loadedcat.add(CategoryP(
          id: prodId,
          name: prodData['name'],
          image: prodData['image'],

          //  favoriteData == null ? false : favoriteData[prodId] ?? false,

        ));
      });
      _cat = loadedcat;
      print(_cat[0].name);
     // notifyListeners();

    } catch (error) {
      throw (error);
    }
  }
}