
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class Appetizer extends ChangeNotifier{
  final String appetizerId;
  final double appetizerPrice;
  final String appetizerName;
  bool _isChecked =false ;


  //String selected;

  Appetizer({
  this.appetizerId,
    this.appetizerName,
    this.appetizerPrice,


  });
  void setFavValue(bool newValue) {
    _isChecked = newValue;
    notifyListeners();
  }
  bool get ischeck{return _isChecked;}

}

  class AppetizerProvider extends ChangeNotifier {




    List<Appetizer> _items = [];
    List<Appetizer> get items {
      return [..._items];
    }
      Future<void> fetchAndSetProducts() async {
        //  final filterString = filterByUser ? 'orderBy="creatorId"&equalTo="$userId"' : '';
        var url = 'https://test-8de9e.firebaseio.com/appetizer.json';
        //  '?auth=$authToken&$filterString;
        try {
          final response = await http.get(url);
          print(json.decode(response.body));
          final extractedData = json.decode(response.body) as Map<
              dynamic,
              dynamic>;
          if (extractedData == null) {
            return;
          }


          final List<Appetizer> loadedProducts = [];
          extractedData.forEach((prodId, prodData) {
            loadedProducts.add(Appetizer(
           appetizerId: prodId,
              appetizerName: prodData['title'],
              appetizerPrice: prodData['price']
            ));
          });
          _items = loadedProducts;
          print(_items);




          notifyListeners();
        } catch (error) {
          throw (error);
        }
      }
  }
  //
