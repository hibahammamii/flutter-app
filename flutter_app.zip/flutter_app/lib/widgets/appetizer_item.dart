import 'package:flutter/material.dart';
import 'package:flutter_app/providers/appetizer.dart';
import 'package:provider/provider.dart';

import '../constants.dart';
import '../providers/cart.dart';
import '../providers/price.dart';
import '../providers/product.dart';

class AppetizerItem extends StatelessWidget {

  //  final String appetizerId;
  // final double appetizerPrice;
  // final String appetizerName;
  //
  //
  //
  // AppetizerItem({
  //   this.appetizerId,
  //   this.appetizerName,
  //   this.appetizerPrice,
  //
  //
  // });



  @override
  Widget build(BuildContext context) {

    final priceProvider = Provider.of<PriceProvider>(context);
    final appetizer = Provider.of<Appetizer>(context);




    return
       Container(
      margin: const EdgeInsets.only(left: 20),



      child:  CheckboxListTile(
        title: Text(appetizer.appetizerName),
          value: appetizer.ischeck,
          onChanged: (value) {
    if (priceProvider.selected == null) {
      showDialog<String>(
          context: context,
          builder: (BuildContext context) =>
              AlertDialog(
                title: const Text('Warning'),
                content: const Text('Please select ....'),
                actions: <Widget>[
                  TextButton(
                    onPressed: () =>
                        Navigator.pop(context, 'Cancel'),
                    child: const Text('Cancel'),
                  ),
                  TextButton(
                    onPressed: () =>
                        Navigator.pop(context, 'OK'),
                    child: const Text('OK'),
                  ),
                ],
              ));
    }
    else{
    appetizer.setFavValue(value);

    if(appetizer.ischeck != false)
    priceProvider.addPrice(appetizer.appetizerPrice);
    else
    priceProvider.minPrice(appetizer.appetizerPrice);
    }

          }));



  }
}
