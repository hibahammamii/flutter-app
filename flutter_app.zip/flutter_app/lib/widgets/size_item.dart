import 'package:flutter/material.dart';
import 'package:flutter_app/providers/appetizer.dart';
import 'package:flutter_app/screens/product_detail_screen.dart';
import 'package:provider/provider.dart';

import '../constants.dart';
import '../providers/cart.dart';
import '../providers/price.dart';
import '../providers/product.dart';

class SizeItem extends StatelessWidget {
// final String id;
// final String title;
// final String imageUrl;
  final String idPrice;
  final double price;
  // final String id;
  // final String title;

  SizeItem(this.idPrice, this.price);


  bool __isActive = false;

  @override
  Widget build(BuildContext context) {
    final product = Provider.of<Product>(context,listen: false);

    final priceProvider = Provider.of<PriceProvider>(context);
    final appetizerProvider = Provider.of<AppetizerProvider>(context,listen: true);
  //  final product = Provider.of<Product>(context);

    final app =appetizerProvider.items;





    return Container(
      margin: const EdgeInsets.only(left: 20),

      child: Row(children: [
        Radio(
          value: idPrice,
          groupValue: priceProvider.selected,
          onChanged: (value) {

            priceProvider.setValue(idPrice);
            priceProvider.setPrice(price);

            app.forEach((element) {element.setFavValue(false);});
           // for(int i =1; i<l ;i++)
           //    product.appetizer[i].isChecked =false;









          },
        ),
        Text(idPrice),
      ],

      ),
      //Radio(value: value, groupValue: groupValue, onChanged: onChanged)
      // TextButton(
      //   onPressed: () {
      //     priceProvider.setValue(idPrice);
      //     priceProvider.setPrice(price);
      //     /* cart.addItem( widget.id,widget.price,widget.title,widget.idprice
      //     );*/
      //    // print(id + price.toString() + title + "  "+idPrice);
      //   },
      //   child: Text(idPrice
      //       //  textAlign: TextAlign.center,
      //       ),
      //   style: TextButton.styleFrom(
      //     backgroundColor: priceProvider.selected == idPrice
      //         ? kPrimaryColor
      //         : ksecondaryColor,
      //     primary: Colors.white,
      //     textStyle: TextStyle(
      //         color: Colors.black,
      //         fontSize: 12,
      //         fontStyle: FontStyle.normal),
      //   ),
      // ),


    );
  }
}
