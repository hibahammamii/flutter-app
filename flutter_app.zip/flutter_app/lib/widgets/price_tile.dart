import 'package:flutter/material.dart';
import 'package:flutter_app/providers/price.dart';
import 'package:provider/provider.dart';


class PriceTile extends StatelessWidget {
  //const PriceTile({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final priceProvider = Provider.of<PriceProvider>(context);
    return  priceProvider.selected == null
          ? Text('0.00')
          : Text('${priceProvider.price.toStringAsFixed(2)} L.E');

  }
}
