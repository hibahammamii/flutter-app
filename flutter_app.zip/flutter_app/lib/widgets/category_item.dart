import 'package:flutter/material.dart';
import 'package:flutter_app/providers/category.dart';
import 'package:provider/provider.dart';

import '../screens/product_detail_screen.dart';
import '../providers/category.dart';

//import '../providers/cart.dart';
import '../providers/auth.dart';
import '../providers/products.dart';
import 'package:flutter_app/constants.dart';
import 'package:flutter_app/size_config.dart';
import '../screens/products_overview_screen.dart';

class CategryItem extends StatelessWidget {
  // final String id;
  // final String title;
  // final String imageUrl;
  final String id;
  final String name;
  final String image;

  String selected = "beef";

  CategryItem(this.id, this.name, this.image);

  // ProductItem(this.id, this.title, this.imageUrl);

  @override
  Widget build(BuildContext context) {
    final categoryData = Provider.of<CategoryP>(context, listen: false);
    final categoriesData = Provider.of<Categories>(context, listen: false);
    final product = Provider.of<Products>(context, listen: false);


    print("x=" + name);
    //final cart = Provider.of<Cart>(context, listen: false);
    //  final authData = Provider.of<Auth>(context, listen: false);
    return Container(
      height: 30,
        margin: const EdgeInsets.only(left: 20),
        child: InkWell(
          onTap: () {
            product.findByCat(categoryData.name);
           categoriesData.setValue(name);
          //  selected =categorydata.name;
          },
          child: Column(
            children: <Widget>[
              Text(
                name,
                style: categoriesData.selected == name
                    ? TextStyle(
                        color: kTextColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 18)
                    : TextStyle(fontSize: 15),
              ),
              if (categoriesData.selected == categoryData.name)
                Container(
                  margin: EdgeInsets.symmetric(vertical: 5),
                  height: 3,
                  width: 30,
                  decoration: BoxDecoration(
                    color: kPrimaryColor,
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
            ],
          ),
        ));
    /* Container(
        height: 70,
        width: 90,
        child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(25.0),
            ),
            elevation: 10,
            child: InkWell(
                onTap: () {
                  category.findByCat(categorydata.name);
                  print("jj");
                  print(categorydata.id);
                  print(category.items);
                },
                //productsData.fetchAndSetProducts();

                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    /* GestureDetector(
    onTap: () {
     /*Navigator.of(context).pushNamed(
         ProductsOverviewScreen.routeName,
          arguments: category.id);*/

    },),*/
                    Container(
                        // padding: EdgeInsets.only(right:22),
                        child: Image.network(
                      image,
                      height: 35,
                    )),
                    SizedBox(
                      height: 3,
                    ),
                    Container(
                      //padding: EdgeInsets.only(right:22),
                      child: Text(name),
                    ),
                  ],
                ))))*/
    ;
  }
}
