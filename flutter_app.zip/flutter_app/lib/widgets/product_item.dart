import 'package:flutter/material.dart';
import 'package:flutter_app/constants.dart';
import 'package:flutter_app/providers/price.dart';
import 'package:provider/provider.dart';

import '../screens/product_detail_screen.dart';
import '../providers/product.dart';

//import '../providers/cart.dart';
import '../providers/auth.dart';

class ProductItem extends StatelessWidget {
  // final String id;
  // final String title;
  // final String imageUrl;

  // ProductItem(this.id, this.title, this.imageUrl);

  @override
  Widget build(BuildContext context) {
    final product = Provider.of<Product>(context, listen: false);
    //final cart = Provider.of<Cart>(context, listen: false);
    final authData = Provider.of<Auth>(context, listen: false);
   // final pricePro =Provider.of<Price>(context, listen: false);
    print(product.type);
    return Container(
      decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.05),
                offset: Offset.zero,
                blurRadius: 15.0)
          ],
          borderRadius: BorderRadius.circular(15)),
      child: Column(
        children: [
          Expanded(
            child: Stack(
              children: [
                Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                        image: DecorationImage(
                      alignment: Alignment.bottomCenter,
                      image: NetworkImage(
                        product.imageUrl,
                        // width: double.infinity,
                      ),
                    ))),
                Consumer<Product>(
                  builder: (ctx, product, _) => Positioned(
                    right: 1,
                    child: IconButton(
                        alignment: Alignment.topLeft,
                        icon: Icon(
                          product.isFavorite
                              ? Icons.favorite
                              : Icons.favorite_border,
                        ),
                        color: kPrimaryColor,
                        onPressed: () {
                          product.toggleFavoriteStatus(
                              authData.token,
                              authData.userId,);
                        }),
                  ),

                  ),


              ],
            ),
          ),
          Container(
            height: 70,
            child: Column(
              children: [
                Container(
                  alignment: Alignment.topCenter,
                  child: Text(
                    product.title,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.black,
                        fontStyle: FontStyle.normal,
                        fontWeight: FontWeight.bold,
                        fontSize: 15),
                  ),
                ),

                Spacer(),
                Container(
                    width: 70,
                    // alignment: Alignment.bottomRight,
                    decoration:
                        BoxDecoration(borderRadius: BorderRadius.circular(40)),

                    // color: ksecondaryColor,

                    child:  TextButton(
                        onPressed: () {
                         Navigator.of(context).pushNamed(

                              ProductDetailScreen.routeName,
                              arguments: product.id,);
                        
                        },
                        child: Text("order now"
                            //  textAlign: TextAlign.center,
                            ),
                        style: TextButton.styleFrom(
                          backgroundColor: kPrimaryColor,
                          primary: Colors.white,
                          textStyle: TextStyle(
                              color: Colors.black,
                              fontSize: 12,
                              fontStyle: FontStyle.normal),
                        ),
                      ),
                    ),
              ],
            ),
          ),
        ],
      ),
    );
    /* ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: GridTile(
        child: GestureDetector(
          onTap: () {
            Navigator.of(context).pushNamed(
              ProductDetailScreen.routeName,
              arguments: product.id,
            );
          },
          child: Image.network(
            product.imageUrl,
            fit: BoxFit.cover,
          ),
        ),
        footer: GridTileBar(
        //  backgroundColor: Colors.black87,
          leading: Consumer<Product>(
            builder: (ctx, product, _) => IconButton(
                  icon: Icon(
                    product.isFavorite ? Icons.favorite : Icons.favorite_border,
                  ),
                  color: Theme.of(context).accentColor,
                  onPressed: () {
                   // product.toggleFavoriteStatus(
                    //  authData.token,
                     // authData.userId,
                  //  );
                  },
                ),
          ),
          title: Text(
            product.title,
            textAlign: TextAlign.center,
          ),
          trailing: IconButton(
            icon: Icon(
              Icons.shopping_cart,
            ),
            onPressed: () {
             // cart.addItem(product.id, product.price, product.title);
              Scaffold.of(context).hideCurrentSnackBar();
              Scaffold.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'Added item to cart!',
                  ),
                  duration: Duration(seconds: 2),
                  action: SnackBarAction(
                    label: 'UNDO',
                    onPressed: () {
                     // cart.removeSingleItem(product.id);
                    },
                  ),
                ),
              );
            },
            color: Theme.of(context).accentColor,
          ),
        ),
      ),
    );*/
  }
}
