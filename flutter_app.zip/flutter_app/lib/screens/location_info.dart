import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/constants.dart';
import 'package:flutter_app/providers/cart.dart';
import 'package:flutter_app/providers/location.dart' show Location;
import 'package:flutter_app/providers/orders.dart';
import 'package:flutter_app/widgets/location_item.dart';
import 'package:provider/provider.dart';

import 'location_screen.dart';

class LocationInfo extends StatelessWidget {
  static const routeName = '/location';

  @override
  Widget build(BuildContext context) {
    final cart = Provider.of<Cart>(context);
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text('Location Info'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Card(
              margin: EdgeInsets.all(15),
              child: Padding(
                padding: EdgeInsets.all(8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text(
                      'Total',
                      style: TextStyle(fontSize: 20),
                    ),
                    SizedBox(
                      width: 30,
                    ),
                    Chip(
                      label: Text(
                        '${cart.totalAmount.toStringAsFixed(2)} L.E',
                        style: TextStyle(
                          color: Colors.black,
                        ),
                      ),
                      backgroundColor: kPrimaryColor,
                    ),
                    ConfirmationButton(cart: cart),
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Text(
              "Choose your location",
              style: TextStyle(
                  fontStyle: FontStyle.normal, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 20.0, top: 8.0, right: 20.0, bottom: 0.0),
              child: FutureBuilder(
                future: Provider.of<Location>(context, listen: false)
                    .fetchAndSetOrders(),
                builder: (ctx, dataSnapshot) {
                  if (dataSnapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  } else {
                    if (dataSnapshot.error != null) {
                      // ...
                      // Do error handling stuff
                      return Center(
                        child: Text('An error occurred!'),
                      );
                    } else {
                      return Consumer<Location>(
                        builder: (ctx, locationData, child) => ListView.builder(
                          itemCount: locationData.location.length,
                          itemBuilder: (ctx, i) =>
                              LocationItem(locationData.location[i]),
                        ),
                      );
                    }
                  }
                },
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => LocationScreen()));
        },
        child: const Icon(Icons.add),
        backgroundColor: kPrimaryColor,
      ),
    );
  }
}

class ConfirmationButton extends StatefulWidget {
  const ConfirmationButton({
    Key key,
    @required this.cart,
  }) : super(key: key);

  final Cart cart;

  @override
  _ConfirmatrionButtonState createState() => _ConfirmatrionButtonState();
}

class _ConfirmatrionButtonState extends State<ConfirmationButton> {
  var _isLoading = false;
  LocationItem locationItem;

  @override
  Widget build(BuildContext context) {
    final locationProvider = Provider.of<Location>(context, listen: true);
    int index = locationProvider.location.indexWhere(
        (element) => element.id == locationProvider.selectedLocation);

    return FlatButton(
      child: _isLoading ? CircularProgressIndicator() : Text('ORDER NOW'),
      onPressed: (widget.cart.totalAmount <= 0 ||
              _isLoading ||
              locationProvider.selectedLocation == null)
          ? null
          : () async {
              setState(() {
                _isLoading = true;
              });
              await Provider.of<Orders>(context, listen: false).addOrder(
                widget.cart.items.values.toList(),
                widget.cart.totalAmount,
                locationProvider.location[index],
              );
              setState(() {
                _isLoading = false;
              });
              widget.cart.clear();
            },
      textColor: Theme.of(context).primaryColor,
    );
  }
}
