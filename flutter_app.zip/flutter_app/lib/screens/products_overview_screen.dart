import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app/providers/appetizer.dart';
import 'package:flutter_app/providers/price.dart';
import 'package:flutter_app/widgets/AnimatedBottomNavigationBar.dart';
import 'package:flutter_app/widgets/app_drawer.dart';

import 'package:provider/provider.dart';

import '../widgets/products_grid.dart';
import '../providers/products.dart';
import '../widgets/category_list.dart';
import '../providers/category.dart';
import '../widgets/slider.dart';
import 'package:flutter_app/constants.dart';
import '../widgets/discount_card.dart';
import 'cart_screen.dart';

enum FilterOptions {
  Favorites,
  All,
}

class ProductsOverviewScreen extends StatefulWidget {
  //static const routeName = '/productoverview-detail';
  static const routeName = '/product-view';

  @override
  _ProductsOverviewScreenState createState() => _ProductsOverviewScreenState();
}

class _ProductsOverviewScreenState extends State<ProductsOverviewScreen> {
  var _showOnlyFavorites = false;
  var _isInit = true;
  var _isLoading = false;
  static MediaQueryData _mediaQueryData;
  static double screenWidth;
  static double screenHeight;

  @override
  void initState() {
    // Provider.of<Products>(context).fetchAndSetProducts(); // WON'T WORK!
    // Future.delayed(Duration.zero).then((_) {
    //   Provider.of<Products>(context).fetchAndSetProducts();
    // });
    super.initState();
  }

  @override
  void didChangeDependencies() {
    if (_isInit) {
      setState(() {
        _isLoading = true;
      });
      // Provider.of<Categories>(context).fetchAndSetProducts().then((_){});

    Provider.of<Categories>(context).fetchAndSetProducts().then((_) {
        setState(() {
          _isLoading = false;
        });
      });
      Provider.of<AppetizerProvider>(context).fetchAndSetProducts().then((_) {
        setState(() {
          _isLoading = false;
        });
      });



      Provider.of<Products>(context).fetchAndSetProducts().then((_) {
        setState(() {
          _isLoading = false;
        });
      });
    }
    //  Provider.of<Products>(context).getCategories().then((_)
    // {

    //});
    _isInit = false;

    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    _mediaQueryData = MediaQuery.of(context);
    screenWidth = _mediaQueryData.size.width;
    screenHeight = _mediaQueryData.size.height;
   // final animated = Provider.of<AnimatedBar>(context, listen: false);
   // final price = Provider.of<PriceProvider>(context,listen: false);

   


    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          // backgroundColor: Colors.white,
          elevation: 0,
          centerTitle: true,
          title: RichText(
            text: TextSpan(
              style: Theme.of(context)
                  .textTheme
                  .title
                  .copyWith(fontWeight: FontWeight.bold),
              children: [
                TextSpan(
                  text: "Papa's",
                  style: TextStyle(color: kPrimaryColor),
                ),
                //SizedBox(width: 3,),
                TextSpan(
                  text: "  Burger",
                  style: TextStyle(color: ksecondaryColor),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            IconButton(
              onPressed:() {Navigator.of(context).pushNamed(CartScreen.routeName);},

              color: Colors.black,
              icon: Icon(
                Icons.shopping_cart,
              ),
            )
          ],
         /* leading: IconButton(
            color: Colors.black,
            icon: Icon(Icons.menu),
            tooltip: 'Menu Icon',
            onPressed: () {},
          ),*/
          brightness: Brightness.dark, //IconButton

          //IconBut
          /* title: Text('MyShop'),
        actions: <Widget>[
          PopupMenuButton(
            onSelected: (FilterOptions selectedValue) {
              setState(() {
                if (selectedValue == FilterOptions.Favorites) {
                  _showOnlyFavorites = true;
                } else {
                  _showOnlyFavorites = false;
                }
              });
            },
            icon: Icon(
              Icons.more_vert,
            ),
            itemBuilder: (_) => [
                  PopupMenuItem(
                    child: Text('Only Favorites'),
                    value: FilterOptions.Favorites,
                  ),
                  PopupMenuItem(
                    child: Text('Show All'),
                    value: FilterOptions.All,
                  ),
                ],
          ),
         Consumer<Cart>(
            builder: (_, cart, ch) => Badge(
                  child: ch,
                  value: cart.itemCount.toString(),
                ),
            child: IconButton(
              icon: Icon(
                Icons.shopping_cart,
              ),
              onPressed: () {
                Navigator.of(context).pushNamed(CartScreen.routeName);
              },
            ),
          ),
        ],*/
        ),
        drawer: AppDrawer(),
        body: Column(
          children: [
            SizedBox(
              height: 2,
            ),
            /* Container(
              //margin: const EdgeInsets.only(left: 10.0),
                padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      'PAPA`S BURGER',
                      style:
                          TextStyle(fontWeight: FontWeight.w900, fontSize: 20),
                    ),
                  ),
                  Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        'Delivary',
                        style: TextStyle(
                            fontWeight: FontWeight.normal,
                            color: Color.fromRGBO(169, 169, 169, 1)),
                      ))
                ],
              ),
            ),*/

            DiscountCard(),
            Expanded(
                child: _isLoading
                    ? Center(
                  child: CircularProgressIndicator(),
                ):

            CategoryList(),
            ),


            Expanded(
              flex: 8,

              child: Consumer<Products>(
                  builder: (context, product, child) => Container(
                      child: _isLoading
                          ? Center(
                              child: CircularProgressIndicator(),
                            )
                          : ProductsGrid(_showOnlyFavorites))),
            ),

            /* SingleChildScrollView(
              child: Expanded(
                  child: Column(
                children: [
                  Container(

                    padding: const EdgeInsets.fromLTRB(10, 0, 10, 0),
                    width: screenWidth,
                    height: 75,
                    child: Expanded(
                      child: CategoryList(),
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Consumer<Products>(
                    builder: (context, product, child) => Container(
                        child: _isLoading
                            ? Center(
                                child: CircularProgressIndicator(),
                              )

                            ),
                  ),
                  SizedBox(
                    height: 20,
                  )
                ],
              )),
            )*/
          ],
        ),
        floatingActionButton:AnimatedBottom(),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        bottomNavigationBar: AnimatedBar(),


        //other params

    );
  }
}
