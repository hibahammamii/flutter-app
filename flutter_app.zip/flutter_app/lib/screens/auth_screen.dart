import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_app/constants.dart';
import 'package:flutter_app/screens/facebook_screen.dart';
import 'package:provider/provider.dart';

import '../providers/auth.dart';
import '../models/http_excption.dart';
import 'package:flutter_app/size_config.dart';

enum AuthMode { Signup, Login, resetpassword }

class AuthScreen extends StatelessWidget {
  static const routeName = '/auth';
  static MediaQueryData _mediaQueryData;
  static double screenWidth;
  static double screenHeight;

  @override
  Widget build(BuildContext context) {
    final deviceSize = MediaQuery.of(context).size;
    _mediaQueryData = MediaQuery.of(context);
    screenWidth = _mediaQueryData.size.width;
    screenHeight = _mediaQueryData.size.height;
    // final transformConfig = Matrix4.rotationZ(-8 * pi / 180);
    // transformConfig.translate(-10.0);
    return Scaffold(
      // resizeToAvoidBottomInset: false,
      body: SingleChildScrollView(
        child: Container(
            decoration: BoxDecoration(
              color: Color.fromRGBO(255, 221, 89, 0.4),
            ),
            height: screenHeight,
            child: Column(
              children: [
                Container(
                    height: screenWidth * 0.5,
                    child: Image(image: AssetImage('assets/images/burger.png'))),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    width: screenWidth * 0.8,

                    child: AuthCard(),
                  ),
                ),
              ],
            )),
      ),
    );
  }
}

class AuthCard extends StatefulWidget {
  const AuthCard({
    Key key,
  }) : super(key: key);

  @override
  _AuthCardState createState() => _AuthCardState();
}

class _AuthCardState extends State<AuthCard> {
  final GlobalKey<FormState> _formKey = GlobalKey();
  AuthMode _authMode = AuthMode.Login;
  Map<String, String> _authData = {
    'email': '',
    'password': '',
  };
  var _isLoading = false;
  final _passwordController = TextEditingController();

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('An Error Occurred!'),
        content: Text(message),
        actions: <Widget>[
          FlatButton(
            child: Text('Okay'),
            onPressed: () {
              Navigator.of(ctx).pop();
            },
          )
        ],
      ),
    );
  }

  Future<void> _submit() async {
    if (!_formKey.currentState.validate()) {
      // Invalid!
      return;
    }
    _formKey.currentState.save();
    setState(() {
      _isLoading = true;
    });
    try {
      if (_authMode == AuthMode.Login) {
        // Log user in
        await Provider.of<Auth>(context, listen: false).login(
          _authData['email'],
          _authData['password'],
        );
      } else {
        // Sign user up
        await Provider.of<Auth>(context, listen: false).signup(
          _authData['email'],
          _authData['password'],
        );
      }
    } on HttpException catch (error) {
      var errorMessage = 'Authentication failed';
      if (error.toString().contains('EMAIL_EXISTS')) {
        errorMessage = 'This email address is already in use.';
      } else if (error.toString().contains('INVALID_EMAIL')) {
        errorMessage = 'This is not a valid email address';
      } else if (error.toString().contains('WEAK_PASSWORD')) {
        errorMessage = 'This password is too weak.';
      } else if (error.toString().contains('EMAIL_NOT_FOUND')) {
        errorMessage = 'Could not find a user with that email.';
      } else if (error.toString().contains('INVALID_PASSWORD')) {
        errorMessage = 'Invalid password.';
      }
      _showErrorDialog(errorMessage);
    } catch (error) {
      const errorMessage =
          'Could not authenticate you. Please try again later.';
      _showErrorDialog(errorMessage);
    }

    setState(() {
      _isLoading = false;
    });
  }

  void _switchAuthMode() {
    if (_authMode == AuthMode.Login) {
      setState(() {
        _authMode = AuthMode.Signup;
      });
    } else if (_authMode == AuthMode.resetpassword) {
      setState(() {
        _authMode = AuthMode.resetpassword;
      });
    } else {
      setState(() {
        _authMode = AuthMode.Login;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final deviceSize = MediaQuery.of(context).size;
    return Form(
      key: _formKey,
      child: Column(
        children: <Widget>[
          TextFormField(
            decoration: InputDecoration(
              labelText: 'E-Mail',
              fillColor: kPrimaryColor,
              border: OutlineInputBorder(
                borderSide: BorderSide(
                  color: kPrimaryColor,

                  ///  color: Colors.red,//this has no effect
                ),
                borderRadius: BorderRadius.circular(10.0),
              ),
            ),
            keyboardType: TextInputType.emailAddress,
            validator: (value) {
              if (value.isEmpty || !value.contains('@')) {
                return 'Invalid email!';
              }
            },
            onSaved: (value) {
              _authData['email'] = value;
            },
          ),
          SizedBox(
            height: 20,
          ),
          // if(AuthMode == AuthMode.Login || AuthMode == AuthMode.Signup)
          TextFormField(
            decoration: InputDecoration(
              labelText: 'Password',
              border: OutlineInputBorder(
                borderSide: BorderSide(
                    // color: Colors.red,//this has no effect
                    ),
                borderRadius: BorderRadius.circular(10.0),
              ),
            ),
            obscureText: true,
            controller: _passwordController,
            validator: (value) {
              if (value.isEmpty || value.length < 5) {
                return 'Password is too short!';
              }
            },
            onSaved: (value) {
              _authData['password'] = value;
            },
          ),
          SizedBox(
            height: 20,
          ),
          if (_authMode == AuthMode.Signup)
            TextFormField(
              enabled: _authMode == AuthMode.Signup,
              decoration: InputDecoration(
                  labelText: 'Confirm Password',
                  border: OutlineInputBorder(
                    borderSide: BorderSide(
                        //color: Colors.red,//this has no effect
                        ),
                    borderRadius: BorderRadius.circular(10.0),
                  )),
              obscureText: true,
              validator: _authMode == AuthMode.Signup
                  ? (value) {
                      if (value != _passwordController.text) {
                        return 'Passwords do not match!';
                      }
                    }
                  : null,
            ),
          SizedBox(
            height: 20,
          ),
          if (_isLoading)
            CircularProgressIndicator()
          else
            RaisedButton(
              child: Text(_authMode == AuthMode.Login ? 'LOGIN' : 'SIGN UP'),
              onPressed: _submit,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
              padding: EdgeInsets.symmetric(horizontal: 30.0, vertical: 8.0),
            ),
          FlatButton(
            child: Text(
                '${_authMode == AuthMode.Login ? 'SIGNUP' : 'LOGIN'} INSTEAD'),
            onPressed: _switchAuthMode,
            padding: EdgeInsets.symmetric(horizontal: 30.0, vertical: 4),
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
          FacebookLogIn(),
        ],
      ),
    );
  }
}
