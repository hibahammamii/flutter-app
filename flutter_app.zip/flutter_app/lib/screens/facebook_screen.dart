import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_app/providers/auth.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:firebase_auth/firebase_auth.dart';


class FacebookLogIn extends StatefulWidget {
  @override
  _FacebookLoginState createState() => new _FacebookLoginState();


}

class _FacebookLoginState extends State<FacebookLogIn> {

  Auth auth;


  Future signInWithFacebook() async {
    // Trigger the sign-in flow
    final AccessToken res = await FacebookAuth.instance.accessToken;
    auth.tokenSet(res.token);
    return await FirebaseAuth.instance.signInWithFacebook(accessToken: res.token);
  }

  @override
  Widget build(BuildContext context) {
    auth = Provider.of<Auth>(context, listen: false);

    return new Center(
        child: new Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[

            new RaisedButton(
              onPressed:() => signInWithFacebook(),
              child: new Text('Log in'),
            ),
            new RaisedButton(
              onPressed: () => {},
              child: new Text('Logout'),
            ),
          ],
        ));
  }
}