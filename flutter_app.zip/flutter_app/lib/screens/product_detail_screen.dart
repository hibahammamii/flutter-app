import 'package:flutter/material.dart';
import 'package:flutter_app/providers/appetizer.dart';
import 'package:flutter_app/providers/price.dart';
import 'package:flutter_app/providers/product.dart';

import 'package:flutter_app/widgets/AnimatedBottomNavigationBar.dart';
import 'package:flutter_app/widgets/appetizer_item.dart';
import 'package:flutter_app/widgets/price_tile.dart';
import 'package:flutter_app/widgets/size_item.dart';
import 'package:provider/provider.dart';

import '../constants.dart';
import '../providers/products.dart';

import '../providers/cart.dart';

class ProductDetailScreen extends StatelessWidget {
  static const routeName = '/product-detail';

  @override
  Widget build(BuildContext context) {
    // final pro = Provider.of<Products>(context, listen: false);
    final priceProvider = Provider.of<PriceProvider>(context, listen: true);
    final cart = Provider.of<Cart>(context, listen: false);
    final appetizerProvider = Provider.of<AppetizerProvider>(context, listen: true);

   

    final productId =
        ModalRoute.of(context).settings.arguments as String; // is the id!
    final loadedProduct = Provider.of<Products>(
      context,
      listen: false,
    ).findById(productId);
    List<Appetizer>  checkAppetizer= [];


    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(
          color: Colors.black, //change your color here
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            priceProvider.setValue(null);
            priceProvider.setPrice(null);
            Navigator.pop(context);
          },
        ),
        // backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        title: Text(
          loadedProduct.title,
          style: TextStyle(color: kPrimaryColor),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            flex: 3,
            child: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.only(left:20,top:0,right:20,bottom:0),
                child: Column(
                  children: <Widget>[
                    Container(
                      height: 200,
                      width: double.infinity,
                      child: Image.network(
                        loadedProduct.imageUrl,
                        fit: BoxFit.cover,
                      ),
                    ),
                    SizedBox(height: 10),
                    Align(
                      alignment: Alignment.topLeft,
                      child: Text("Description",
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                          )),
                    ),
                    SizedBox(height: 10),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 10),
                      width: double.infinity,
                      child: Text(loadedProduct.description,
                          textAlign: TextAlign.right,
                          softWrap: true,
                          style: TextStyle(
                            color: Colors.black,
                            // fontWeight: FontWeight.bold,
                            fontSize: 16,
                          )),
                    ),
                    SizedBox(height: 10),
                    SizedBox(
                      height: 10,
                    ),
                   Container(
                        height: 150,
                        child: ListView.builder(
                            scrollDirection: Axis.vertical,
                            itemCount: loadedProduct.type.length,
                            itemBuilder: (ctx, i) => ChangeNotifierProvider.value(
                                // builder: (c) => products[i],

                                value: loadedProduct.type[i],
                                child: SizeItem(
                                  loadedProduct.type[i].typeId,
                                  loadedProduct.type[i].price,
                                  // loadedProduct.title,
                                  // loadedProduct.id
                                ))),
                      ),


                    /*Row(
                        children: [
                          Text("price"),
                          SizedBox(
                            width: 20,
                          ),
                          Consumer<Price>(
                            builder: (context, _, child) => Container(
                              child: PriceTile()

                            ),
                          ),
                        ],
                      )*/
                    Divider(color: Colors.black),
                    Align(
                      alignment: Alignment.topLeft,
                      child: Text("Appetizer",
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                          )),
                    ),

                      SingleChildScrollView(
                        child: Container(
                          height: 90,
                          child:
                                AppetizerList(),
                          ),
                        ),


                    SizedBox(
                      height: 10,
                    ),

                  ],
                ),
              ),
            ),
          ),
          Divider(color: Colors.black),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                margin: const EdgeInsets.fromLTRB(20, 0, 0, 0),
                child: PriceTile(),
              ),
              Spacer(),
              Container(
                margin: const EdgeInsets.fromLTRB(0, 0, 20, 0),
                child: TextButton(
                  onPressed: () {
                    if (priceProvider.selected == null) {
                      showDialog<String>(
                          context: context,
                          builder: (BuildContext context) => AlertDialog(
                            title: const Text('Warning'),
                            content: const Text('Please select ....'),
                            actions: <Widget>[
                              TextButton(
                                onPressed: () =>
                                    Navigator.pop(context, 'Cancel'),
                                child: const Text('Cancel'),
                              ),
                              TextButton(
                                onPressed: () =>
                                    Navigator.pop(context, 'OK'),
                                child: const Text('OK'),
                              ),
                            ],
                          ));
                    } else {
                      appetizerProvider.items.forEach((element) {if(element.ischeck == true)
                        print(element.appetizerName);
                        checkAppetizer.add(element);
                        print(checkAppetizer);
                      });


                      cart.addItem(loadedProduct.id, priceProvider.price,
                          loadedProduct.title, priceProvider.selected,checkAppetizer);
                    }
                  },
                  child: Text("Add to cart"

                  ),
                  style: TextButton.styleFrom(
                    // side: BorderSide(color: Colors.deepOrange, width: 1),
                    elevation: 4,
                    shape: const BeveledRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(4))),
                    backgroundColor: kPrimaryColor,
                    primary: Colors.white,
                    textStyle: TextStyle(
                        color: Colors.black,
                        fontSize: 12,
                        fontStyle: FontStyle.normal),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      floatingActionButton: AnimatedBottom(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: AnimatedBar(),
    );
  }
}

class AppetizerList extends StatelessWidget {


  AppetizerList();

  bool isChecked = false;

  List<Appetizer> appetizer ;
  
  @override
  Widget build(BuildContext context) {
    final appetizer = Provider.of<AppetizerProvider>(context);
    final app =appetizer.items;

    return
       Consumer<Appetizer>(
         builder: (context,_,child)=>
      ListView.builder(
            scrollDirection: Axis.vertical,
            itemCount: app.length,
            itemBuilder: (ctx, i) => ChangeNotifierProvider.value(
                // builder: (c) => products[i],

                value: app[i],
                child: AppetizerItem(


                ))),
       )
    ;
    // TODO: implement build
    throw UnimplementedError();
  }
}
